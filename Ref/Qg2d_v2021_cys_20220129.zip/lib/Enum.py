### -*- coding: utf-8 -*-
#import enum
#class ASC_Header(enum.Enum):
#   NCOLS = enum.auto()
#   NROWS= enum.auto()
#   XLLCORNER= enum.auto()
#   YLLCORNER = enum.auto()
#   CELLSIZE= enum.auto()
#   NODATA_VALUE= enum.auto()

#tauDEMCommand = enum('SK','FLAT','FD', 'FA', 'SG', 'ST', 'STV', 'CAT')