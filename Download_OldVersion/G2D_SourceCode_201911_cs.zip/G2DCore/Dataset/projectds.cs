﻿namespace G2DCore.Dataset
{


    partial class projectds
    {
        partial class HydroParsDataTable
        {
        }

        partial class BoundaryConditionDataDataTable
        {
        }

        partial class ProjectSettingsDataTable
        {
        }
    }
}
