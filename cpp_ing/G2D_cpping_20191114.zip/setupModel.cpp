#include <stdio.h>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <string>
#include <io.h>
#include <cctype>

#include "gentle.h"
#include "g2dLib.h"

using namespace std;
namespace fs = std::filesystem;

extern fs::path fpn_prj;
extern fs::path fpn_log;
extern projectFile prj;
extern domaininfo di;
extern vector<cvinfo> cvsv;
extern cvinfo * cvs;

// set_values_using_rasterFile(project prj) �̺κ� ������ ����
int setupDomainAndCVinfo()
{
	ascRasterFile demfile = ascRasterFile(prj.fpnDEM);

	return 1;
}