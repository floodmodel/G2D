#include <iostream>
#include <string>
#include <stdio.h>
#include <intrin.h>
#include <io.h>
#include <stdlib.h>
#include <sstream>
#include <list>
#include <time.h>
#include <filesystem>
#include <algorithm>
#include "cpuinfodelegate.h"
#include "gpuinfodelegate.h"

#include "gentle.h"

#ifdef _WIN32
	#include <windows.h>
#elif MACOS
	#include <sys/param.h>
	#include <sys/sysctl.h>
#else
	#include <unistd.h>
#endif

//#include "gentle_function.h"

using namespace std;
namespace fs = std::filesystem;

bool appendTextAndCloseFile(const char* fpn, char* printText, int bprintFile, int bprintConsole)
{
	if (bprintConsole > 0)
	{
		printf(printText);
	}
	if (bprintFile > 0)
	{
		std::ofstream outfile;
		if (fs::exists(fpn) == false)
		{
			outfile.open(fpn, ios::out);
		}
		else if (fs::exists(fpn) == true)
		{
			outfile.open(fpn, ios::app);
		}
		time_t now = time(0);
		tm *ltm = localtime(&now);
		string nows = timeToString(ltm);
		outfile << nows + " " + printText;
		outfile.close();

		//FILE* outFile;
		//int nResult = access(fpn, 0);
		//if (nResult == -1)
		//{
		//	outFile = fopen(fpn, "w");
		//}
		//else if (nResult == 0)
		//{
		//	outFile = fopen(fpn, "a");
		//}
		//fprintf(outFile, printText);
		//fclose(outFile);
	}
	return true;
}

bool appendTextAndCloseFile( fs::path fpn, char* printText, int bprintFile, int bprintConsole)
{
	if (bprintConsole > 0)
	{
		printf(printText);
	}

	if (bprintFile > 0)
	{
		std::ofstream outfile;
		if (fs::exists(fpn) == false)
		{
			outfile.open(fpn, ios::out);
		}
		else if (fs::exists(fpn) == true)
		{
			outfile.open(fpn, ios::app);
		}
		time_t now = time(0);
		tm *ltm = localtime(&now);
		string nows = timeToString(ltm);
		outfile << nows + " " + printText;
		outfile.close();

		//FILE* outFile;
		//string pstr = fpn.string();
		//const char* fpn_cchar = pstr.c_str();

		//if (fs::exists(fpn) == false)
		//{
		//	outFile = fopen(fpn_cchar, "w");
		//}
		//else if (fs::exists(fpn) == true)
		//{
		//	outFile = fopen(fpn_cchar, "a");
		//}
		//fprintf(outFile, printText);
		//fclose(outFile);
	}
	return true;
}

bool appendTextAndCloseFile(fs::path fpn, string printText, int bprintFile, int bprintConsole)
{
	if (bprintConsole > 0)
	{
		cout << printText;
	}
	if (bprintFile > 0)
	{
		std::ofstream outfile;
		if (fs::exists(fpn) == false)
		{
			outfile.open(fpn, ios::out);
		}
		else if (fs::exists(fpn) == true)
		{
			outfile.open(fpn, ios::app);
		}
		time_t now = time(0);
		tm *ltm = localtime(&now);
		string nows = timeToString(ltm);
		outfile << nows +" "+ printText;
		outfile.close();
	}
	return true;
}

ascRasterFile::ascRasterFile(string fpn_ascRasterFile)
{
	fs::path fpnASC = fpn_ascRasterFile;
	int r = 0;
	ifstream ascFile(fpnASC);
	if (ascFile.is_open())
	{
		string aline;
		int r = 0;
		while (getline(ascFile, aline))
		{
			if (r > 7) { break; }//7�� �д´�.. ��, 7���� �а�, ������. header�� �ִ� 6���̴�.
			linesForHeader[r] = aline;			
			r++;
		}
	}
	header = getAscRasterHeader(linesForHeader, separator);
	headerStringAll = makeHeaderString(header.nCols, header.nRows,
		header.xllcorner, header.yllcorner, header.cellsize, header.nodataValue);
	extent = getAscRasterExtent(header);
	valuesFromTL = new double*[header.nCols]; //x�� ���� �Ҵ��ϰ�, �Ʒ����� y�� �Ҵ��Ѵ�.
	for (int i = 0; i < header.nCols; i++)
	{
		valuesFromTL[i] = new double[header.nRows];
	}
	bool isBigSize = false;
	if (header.nCols * header.nRows > BigSizeThreshold) { isBigSize = true; }
	int headerEndingIndex = header.headerEndingLineIndex;
	int dataStaringIndex = header.dataStartingLineIndex;
	if (isBigSize == false)
	{
		//int rcountMax = header.nRows + header.headerEndingLineIndex+1;
		vector<string> allLinesv = readTextFileToStringVector(fpn_ascRasterFile);
		int lyMax = allLinesv.size();
#pragma omp parallel for
		for (int ly = header.dataStartingLineIndex; ly < lyMax; ly++)
		{
			vector<string> values = splitToStringVector(allLinesv[ly], ' ');
			int y = ly - dataStaringIndex;
			int nX = values.size();
			for (int x = 0; x < nX; x++)
			{
				if(isNumeric(values[x])== true)
				{
					valuesFromTL[x][y] = stod(values[x]);
				}
				else
				{
					valuesFromTL[x][y] = header.nodataValue;
				}
			}
		}
	}
	else
	{
		//int nl = 0;
		//int y = 0;
		//foreach(string line in File.ReadLines(FPN))
		//{
		//	if (nl > headerEndingIndex)
		//	{
		//		string[] values = line.Split(mSeparator, StringSplitOptions.RemoveEmptyEntries);
		//		for (int x = 0; x < values.Length; x++)
		//		{
		//			double v = 0;
		//			if (double.TryParse(values[x], out v) == true)
		//			{
		//				mValuesFromTL[x, y] = v;
		//			}
		//			else
		//			{
		//				mValuesFromTL[x, y] = Header.nodataValue;
		//			}
		//		}
		//		y++;
		//	}
		//	nl++;
		//}
	}
}


ascRasterHeader ascRasterFile::getAscRasterHeader(string inputLInes[], char separator)
{
	ascRasterHeader header;
	header.dataStartingLineIndex = -1;
	//int arraySize = sizeof(inputLInes) / sizeof(*inputLInes);
	for (int ln = 0; ln < 7; ln++)
	{
		string aline = inputLInes[ln];
		vector<string> LineParts = splitToStringVector(aline, separator);

		int iv = 0;
		double dv = 0;
		switch (ln)
		{
		case 0:
			header.nCols = stoi(LineParts[1]);
			break;
		case 1:
			header.nRows = stoi(LineParts[1]);
			break;
		case 2:
			header.xllcorner = stod(LineParts[1]);
			break;
		case 3:
			header.yllcorner = stod(LineParts[1]);
			break;
		case 4:
			header.cellsize = stod(LineParts[1]);
			break;
		case 5:
			header.nodataValue = stoi(LineParts[1]);
			break;
		}

		if (ln > 4)
		{
			if (LineParts.size() > 0)
			{
				if (isNumeric(LineParts[0])==true)
				{
					header.dataStartingLineIndex = ln;
					header.headerEndingLineIndex = ln - 1;
					return header;
				}
			}
		}
	}
	return header;
}

ascRasterExtent ascRasterFile::getAscRasterExtent(ascRasterHeader header)
{
	ascRasterExtent ext;
	ext.bottom = header.yllcorner;
	ext.top = header.yllcorner + header.nRows * header.cellsize;
	ext.left = header.xllcorner;
	ext.right = header.xllcorner + header.nCols * header.cellsize;
	ext.extentWidth = ext.right - ext.left;
	ext.extentHeight = ext.top - ext.bottom;
	return ext;
}

string ascRasterFile::makeHeaderString(int ncols, int nrows, double xll, double yll, double cellSize, int nodataValue)
{
	string headerall = "";
	headerall =  "ncols " + to_string(ncols) + "\n";
	headerall = headerall + "nrows " + to_string(nrows) + "\n";
	headerall = headerall + "xllcorner " + to_string(xll) + "\n";
	headerall = headerall + "yllcorner " + to_string(yll) + "\n";
	headerall = headerall + "cellsize " + to_string(cellSize) + "\n";
	headerall = headerall + "NODATA_value " + to_string(nodataValue) + "\n";
	return headerall;
}


int confirmDeleteFiles(vector<string> filePathNames)
{
	bool bAlldeleted  = false;
	int n = 0;
	while (!(bAlldeleted == true))
	{
		n += 1;
		for (string fpn : filePathNames)
		{
			if (fs::exists(fpn) == true)
			{
				
				std::remove(fpn.c_str());
			}
		}
		for (string fpn : filePathNames)
		{
			if (fs::exists(fpn) == false)
			{
				bAlldeleted = true;
				break;
			}
			else
			{
				bAlldeleted = false;
				break;
			}
		}
		if (n > 100) { return -1; }
	}
	return 1;
}

bool isNumeric(string instr)
{
	return atoi(instr.c_str()) != 0 || instr.compare("0") == 0;
}
string getCPUinfo()
{
	CPUInfoDelegate *cpuInfo = new CPUInfoDelegate();
	std::vector<CPUInfo> cpuInfoVector = cpuInfo->cpuInfoVector();

		SYSTEM_INFO sysInfo;
	GetSystemInfo(&sysInfo);
	int CPUCount = 1;
	string infoStr;
	infoStr ="  " + std::to_string(cpuInfo->numberOfCPUInfoItems()) + " CPU(s) installed.\n";
	for (std::vector<CPUInfo>::iterator iter = cpuInfoVector.begin(); iter != cpuInfoVector.end(); iter++) 
	{
		//std::cout << "CPU Manufacturer = " << iter->manufacturer() << std::endl;
		//std::cout << "Current CPU Clock Speed = " << iter->currentClockSpeed() << std::endl;
		//std::cout << "CPU Architecture = " << iter->architecture() << std::endl;
		//std::cout << "CPU L2 Cache Size = " << iter->L2CacheSize() << std::endl;
		//std::cout << "CPU L3 Cache Size = " << iter->L3CacheSize() << std::endl;
		//std::cout << "Current CPU Temperature = " << iter->currentTemperature() << std::endl;

		infoStr += "  CPU #" + to_string(CPUCount) + ".\n";
		infoStr += "    CPU name : " + iter->name() + '\n';
		infoStr += "    Number of CPU cores : " + iter->numberOfCores() + '\n';
		infoStr += "    Number of logical processors : " + std::to_string(sysInfo.dwNumberOfProcessors) + '\n';
		CPUCount++;
	}
	delete cpuInfo;
	return infoStr;
}


version getCurrentFileVersion()
{
	TCHAR fpn_exe[MAX_PATH];
	DWORD size = GetModuleFileName(NULL, fpn_exe, sizeof(fpn_exe));
	DWORD infoSize = 0;
	version ver;

	// ���Ϸκ��� ���������������� ũ�Ⱑ �������� ���մϴ�.
	infoSize = GetFileVersionInfoSize(fpn_exe, 0);
	if (infoSize == 0) return ver;

	// �����Ҵ�
	char* buffer = NULL;
	buffer = new char[infoSize];

	if (buffer)
	{
		// �������������͸� �����ɴϴ�.
		if (GetFileVersionInfo(fpn_exe, 0, infoSize, buffer) != 0)
		{
			VS_FIXEDFILEINFO* pFineInfo = NULL;
			UINT bufLen = 0;
			// buffer�� ���� VS_FIXEDFILEINFO ������ �����ɴϴ�.
			if (VerQueryValue(buffer, "\\", (LPVOID*)&pFineInfo, &bufLen) != 0)
			{
				ver.major = HIWORD(pFineInfo->dwFileVersionMS);
				ver.minor = LOWORD(pFineInfo->dwFileVersionMS);
				ver.build = HIWORD(pFineInfo->dwFileVersionLS);
				//ver.LastWrittenTime = new char[30];
				struct _stat buf;
				if (_stat(fpn_exe, &buf) != 0)
				{
					switch (errno) {
					case ENOENT:
						fprintf(stderr, "File %s not found.\n", fpn_exe);
					case EINVAL:
						fprintf(stderr, "Invalid parameter to _stat.\n");
					default:
						fprintf(stderr, "Unexpected error in _stat.\n");
					}
					sprintf(ver.LastWrittenTime, "");
				}
				else
				{
					//printf("%s\n", fpn_exe);
					//printf("\tTime Creation     : %s\n", timeToString(localtime(&buf.st_ctime)));
					//printf("\tTime Last Written : %s\n", timeToString(localtime(&buf.st_mtime)));
					//printf("\tTime Last Access  : %s\n", timeToString(localtime(&buf.st_atime)));
					sprintf(ver.LastWrittenTime, timeToString(localtime(&buf.st_mtime)));
				}
			}
		}
		delete[] buffer;
	}
	return ver;
}

string getGPUinfo()
{
	GPUInfoDelegate *gpuInfo = new GPUInfoDelegate();
	std::vector<GPUInfo> gpuInfoVector = gpuInfo->gpuInfoVector();
	//std::cout << "This computer has " << gpuInfo->numberOfGPUInfoItems() << " GPU(s) installed" << std::endl;
	//int gpuCount = 1;
	//for (std::vector<GPUInfo>::const_iterator iter = gpuInfoVector.begin(); iter != gpuInfoVector.end(); iter++) {
	//	std::cout << "Information for GPU #" << gpuCount << ": " << std::endl;
	//	std::cout << "GPU Name = " << iter->name() << std::endl;
	//	std::cout << "GPU Manufacturer = " << iter->manufacturer() << std::endl;
	//	std::cout << "GPU Adapter RAM = " << iter->adapterRAM() << std::endl;
	//	std::cout << "GPU Refresh Rate = " << iter->refreshRate() << std::endl;
	//	std::cout << "GPU Driver Version = " << iter->driverVersion() << std::endl;
	//	std::cout << "GPU Video Architecture = " << iter->videoArchitecture() << std::endl;
	//	std::cout << "GPU Video Mode Description = " << iter->videoModeDescription() << std::endl;
	//	std::cout << std::endl;
	//	gpuCount++;
	//}

	//SYSTEM_INFO sysInfo;
	//GetSystemInfo(&sysInfo);
	//int CPUCount = 1;
	string infoStr;
	infoStr = "  " + std::to_string(gpuInfo->numberOfGPUInfoItems()) + " GPU(s) installed.\n";
	int gpuCount = 1;
	for (std::vector<GPUInfo>::const_iterator iter = gpuInfoVector.begin(); iter != gpuInfoVector.end(); iter++)
	{
		infoStr += "  GPU #" + to_string(gpuCount) + ".\n";
		infoStr += "    GPU name : " + iter->name() + '\n';
		infoStr += "    GPU adapter ram : " + iter->adapterRAM() + '\n';
		infoStr += "    GPU driver version : " + iter->driverVersion() + '\n';
		gpuCount++;
	}
	delete gpuInfo;
	return infoStr;
}

string getValueStringFromXmlLine(string aLine, string fieldName)
{
	int len_fiedlName = 0;
	int pos1 = 0;
	string strToFind = "<"+ fieldName+">";
	pos1 = aLine.find(strToFind, 0);
	if (pos1 >= 0)
	{
		//pos1 = aLine.find("<DEMFile>", 0);
		len_fiedlName = strToFind.length();
		int pos2 = 0;
		string strToFind2 = "</" + fieldName + ">";
		pos2 = aLine.find(strToFind2);
		if (pos2 >= 0)
		{
			string valueString = "";
			int valueSize = 0;
			valueSize = pos2 - pos1 - len_fiedlName;
			valueString = aLine.substr(pos1 + len_fiedlName, valueSize);
			return valueString;
		}
		return "";
	}
	else
	{
		return "";
	}

}


vector<string> readTextFileToStringVector(string fpn)
{
	ifstream txtFile(fpn);
	string aline;
	vector<string> linesv;
	while (!txtFile.eof())
	{
		getline(txtFile, aline);
		if (aline.size() > 0)
		{
			linesv.push_back(aline);
		}		
	}
	//return &linesv[0];
	return linesv;
}


time_HHMMSS secToHHMMSS(long sec)
{
	time_HHMMSS t;
	t.hours = sec / 3600;
	long remains;
	remains = sec % 3600;
	t.minutes = remains / 60;
	remains = remains % 60;
	t.seconds = remains;
	return t;
}


/*
std::string split implementation by using delimeter as a character.
*/
vector<double> splitToDoubleVector(string stringToBeSplitted, char delimeter, bool removeEmptyEntry)
{
	stringstream ss(stringToBeSplitted);
	double v;
	string item;
	//char * seprator = delimeter.c_str();
	vector<double> splittedValues;
	while (getline(ss, item, delimeter))
	{
		string sv = trim(item);
		if (removeEmptyEntry == true)
		{
			if (sv != "")
			{
				v = stod(sv);
				splittedValues.push_back(v);
			}
		}
		else
		{
			v = stod(sv);
			splittedValues.push_back(v);
		}
	}
	return splittedValues;
}

/*
std::string split implementation by using delimeter as an another string
*/
vector<double> splitToDoubleVector(string stringToBeSplitted, string delimeter, bool removeEmptyEntry )
{
	vector<double> splittedValues;
	int startIndex = 0;
	int  endIndex = 0;
	while ((endIndex = stringToBeSplitted.find(delimeter, startIndex)) < stringToBeSplitted.size())
	{
		string item = stringToBeSplitted.substr(startIndex, endIndex - startIndex);
		string sv = trim(item);
		double val;
		if (removeEmptyEntry == true)
		{
			if (sv != "")
			{
				val = stod(sv);
				splittedValues.push_back(val);
			}
		}
		else
		{
			val = stod(sv);
			splittedValues.push_back(val);
		}
		startIndex = endIndex + delimeter.size();
	}
	if (startIndex < stringToBeSplitted.size())
	{
		string item = stringToBeSplitted.substr(startIndex);
		string sv = trim(item);
		double val;
		if (removeEmptyEntry == true)
		{
			if (sv != "")
			{
				val = stod(sv);
				splittedValues.push_back(val);
			}
		}
		else
		{
			val = stod(sv);
			splittedValues.push_back(val);
		}
	}
	return splittedValues;
}


vector<int> splitToIntVector(string stringToBeSplitted, char delimeter, bool removeEmptyEntry)
{
	stringstream ss(stringToBeSplitted);
	int v;
	string item;
	//char * seprator = delimeter.c_str();
	vector<int> splittedValues;
	while (getline(ss, item, delimeter))
	{
		string sv = trim(item);
		if (removeEmptyEntry == true)
		{
			if (sv != "")
			{
				v = stod(sv);
				splittedValues.push_back(v);
			}
		}
		else
		{
			v = stod(sv);
			splittedValues.push_back(v);
		}
	}
	return splittedValues;
}

vector<string> splitToStringVector(string stringToBeSplitted, char delimeter, bool removeEmptyEntry)
{
	stringstream ss(stringToBeSplitted);
	string v;
	string item;
	//char * seprator = delimeter.c_str();
	vector<string> splittedValues;
	while (getline(ss, item, delimeter))
	{
		v = trim(item);
		if (removeEmptyEntry == true )			
		{
			if (v != "")
			{
				splittedValues.push_back(v);
			}
		}
		else
		{
			splittedValues.push_back(v);
		}

	}
	return splittedValues;
}

char* stringToCharP(string genericString)
{
	std::vector<char> writable(genericString.begin(), genericString.end());
	writable.push_back('\0');
	return &writable[0];
}


string toLower(string instring)
{
	std::transform(instring.begin(), instring.end(), instring.begin(), tolower);
	return instring;
}

string toUpper(string instring)
{
	std::transform(instring.begin(), instring.end(), instring.begin(), toupper);
	return instring;
}

char* timeToString(struct tm* t, int includeSEC) 
{
	static char s[20];
	if (includeSEC < 0)
	{
		sprintf(s, "%04d-%02d-%02d %02d:%02d",
			t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
			t->tm_hour, t->tm_min);// , t->tm_sec);
	}
	else
	{
		sprintf(s, "%04d-%02d-%02d %02d:%02d:%02d",
			t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
			t->tm_hour, t->tm_min, t->tm_sec);
	}
	return s;
}



bool writeNewTextAndCloseFile(const char* fpn, char* printText, int bprintFile, int bprintConsole)
{
	if (bprintConsole > 0)
	{
		printf(printText);
	}
	if (bprintFile > 0)
	{
		time_t now = time(0);
		tm *ltm = localtime(&now);
		string nows = timeToString(ltm);
		std::ofstream outfile;
		outfile.open(fpn, ios::out);
		outfile << nows + " " + printText;
		outfile.close();

		//FILE* outFile;
		//outFile = fopen(fpn, "w");
		//fprintf(outFile, printText);
		//fclose(outFile);
	}
	return true;
}

bool writeNewTextAndCloseFile(fs::path fpn, char* printText, int bprintFile, int bprintConsole)
{
	if (bprintConsole > 0)
	{
		printf(printText);
	}
	if (bprintFile > 0)
	{
		time_t now = time(0);
		tm *ltm = localtime(&now);
		string nows = timeToString(ltm);
		std::ofstream outfile;
		outfile.open(fpn, ios::out);
		outfile << nows + " " + printText;
		outfile.close();

		//FILE* outFile;
		//string pstr = fpn.string();
		//const char* fpn_cchar = pstr.c_str();
		//outFile = fopen(fpn_cchar, "w");
		//fprintf(outFile, printText);
		//fclose(outFile);
	}
	return true;
}

bool writeNewTextAndCloseFile(fs::path fpn, string printText, int bprintFile, int bprintConsole)
{
	if (bprintConsole > 0)
	{
		cout << printText;
	}
	if (bprintFile > 0)
	{
		time_t now = time(0);
		tm *ltm = localtime(&now);
		string nows = timeToString(ltm);
		std::ofstream outfile;
		outfile.open(fpn, ios::out);
		outfile << nows+" "+printText;
		outfile.close();
	}
	return true;
}





