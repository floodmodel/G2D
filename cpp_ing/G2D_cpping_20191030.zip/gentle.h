#pragma once
#include <iostream>
#include <stdio.h>
#include <list>
#include <windows.h>
//#include <string>

using namespace std;


typedef struct cellPosition
{
	int x;
	int y;
};

typedef struct version
{
	WORD major;
	WORD minor;
	WORD build;
	char LastWrittenTime[30];
};

typedef struct time_HHMMSS
{
	long hours;
	int minutes;
	int seconds;
};


enum flowDirection4
{
	//N=1, E = 4, S = 16, W=64, NONE=0
	E4 = 1, S4 = 3, W4 = 5, N4 = 7, NONE4 = 0
};

enum flowDirection8
{
	//N=1, NE=2, E=4, SE=8, S=16,  SW=32, W=64, NW=128, NONE=0
	E8 = 1, SE8 = 2, S8 = 3, SW8 = 4, W8 = 5, NW8 = 6, N8 = 7, NE8 = 8, NONE8 = 0
};


enum rainfallDataType
{
	TextFileMAP, //1
	TextFileASCgrid, //2
	NoneRF //0
};

// 1:Discharge, 2:Depth, 3:Height, 4:None
enum conditionDataType
{
	Discharge, // 1
	Depth,      //2
	Height,    //3
	NoneCD     //4
};


enum fileOrConstant
{
	File,
	Constant,
	None
};



#ifndef function_define
#define function_define  

namespace fs = std::filesystem;

bool appendTextAndCloseFile(const char* fpn, char* printText, int bprintFile, int bprintConsole);
bool appendTextAndCloseFile(fs::path fpn, char* printText, int bprintFile, int bprintConsole);
bool appendTextAndCloseFile(fs::path fpn, string printText, int bprintFile, int bprintConsole);
int confirmDeleteFiles(vector<string> filePathNames);

void g2dHelp();
string getCPUinfo();
version getCurrentFileVersion();
string getGPUinfo();
string getValueStringFromXmlLine(string aLine, string fieldName);
//char* getPath(char *fpn);

int openProjectFile();
int openPrjANDrunG2D();

time_HHMMSS secToHHMMSS(long sec);

vector<double> splitToDoubleVector(string strToSplit, const char delimeter);
vector<double> splitToDoubleVector(string strToSplit, string delimeter);
vector<int> splitToIntVector(string stringToBeSplitted, char delimeter);
vector<string> splitToStringVector(string stringToBeSplitted, char delimeter);

char* stringToCharP(string c_charP);
char* timeToString(struct tm* t, int includeSEC = -1);
string toLower(string instring);
string toUpper(string instring);

bool writeNewTextAndCloseFile(const char* fpn, char* printText, int bprintFile, int bprintConsole);
bool writeNewTextAndCloseFile(fs::path fpn, char* printText, int bprintFile, int bprintConsole);
bool writeNewTextAndCloseFile(fs::path fpn, string printText, int bprintFile, int bprintConsole);

#endif 

inline std::string trim(std::string& str)
{
	str.erase(0, str.find_first_not_of(' '));       //prefixing spaces
	str.erase(str.find_last_not_of(' ') + 1);         //surfixing spaces
	return str;
}

inline std::string trimL(std::string& str)
{
	str.erase(0, str.find_first_not_of(' '));       //prefixing spaces
	return str;
}


inline std::string trimR(std::string& str)
{
	str.erase(str.find_last_not_of(' ') + 1);         //surfixing spaces
	return str;
}

